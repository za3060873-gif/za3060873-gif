<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="banner.svg?v=1">
  <source media="(prefers-color-scheme: light)" srcset="banner-light.svg?v=1">
  <img src="banner.svg?v=1" alt="Sawera Shehzadi banner" width="100%">
</picture>

<br>

<img src="lanyard.svg?v=1" alt="Sawera Shehzadi ID badge" width="220">

</div>

<br>

<div align="center">

### 🚀 About Me

Software Engineering student who loves turning ideas into working code.
Currently building with **Java**, **SQL**, and **Python**, and diving deep into
Data Structures, Database Design, and UML modeling.

</div>

<br>

<div align="center">

## 🧰 Tech Stack

**Languages**
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)

**Tools & Platforms**
![IntelliJ IDEA](https://img.shields.io/badge/IntelliJ_IDEA-000000?style=for-the-badge&logo=intellijidea&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![Figma](https://img.shields.io/badge/Figma-F24E1E?style=for-the-badge&logo=figma&logoColor=white)
![draw.io](https://img.shields.io/badge/draw.io-F08705?style=for-the-badge&logo=diagramsdotnet&logoColor=white)

**Core Concepts**
`Data Structures & Algorithms` · `Database Design & Normalization` · `UML Modeling` · `SRS Documentation` · `Data Labeling & Categorization`

</div>

<br>

<div align="center">
  <img src="stats.svg?v=1" alt="GitHub stats" width="46%">
  &nbsp;&nbsp;
  <img src="langs.svg?v=1" alt="Most used languages" width="46%">
</div>

<br>

<div align="center">
  <img src="trophies.svg?v=1" alt="GitHub trophies" width="90%">
</div>

<br>

## 📂 Featured Projects

| Project | Description | Tech |
|---|---|---|
| **SkillSwap** | Peer-to-peer academic barter platform with token-based exchange, complete SRS documentation and UML design | Java, MySQL, UML |
| **Java AI ChatBot** | Desktop chatbot with a Swing GUI, powered by the Claude API for context-aware conversation | Java, Swing |
| **Snake & Ladder Game** | Classic board game built with Java Swing, combining five different data structures | Java, Swing, DSA |
| **FabJobHunter** | Job-hunting automation system with a JSON file-based architecture | Node.js, Next.js |

<br>

## 📈 Contribution Activity

<div align="center">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=za3060873&theme=react-dark&hide_border=true&area=true" alt="Contribution activity graph" width="95%">
</div>

<br>

<div align="center">
  <img src="https://raw.githubusercontent.com/za3060873/za3060873/output/github-snake-dark.svg#gh-dark-mode-only" alt="contribution snake dark" width="95%">
  <img src="https://raw.githubusercontent.com/za3060873/za3060873/output/github-snake.svg#gh-light-mode-only" alt="contribution snake light" width="95%">
</div>

<br>

## 🔗 Connect With Me

<div align="center">

[![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white)](https://github.com/za3060873)
[![Email](https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:za3060873@gmail.com)

</div>

<br>

<div align="center">
  <img src="https://komarev.com/ghpvc/?username=za3060873&style=for-the-badge&color=ff6ec7" alt="Profile views">
</div>

<div align="center">
  <sub>✨ Always Learning, Always Building ✨</sub>
</div>
